from dataclasses import dataclass
from urllib.parse import urlparse, parse_qsl
from http import HTTPMethod, HTTPStatus

@dataclass
class ServerConfig:
    dir : str = "./api/"
    max_request_size : int = 4096
    server_name : str = "Server"
    path_script_name : str = "path"

class Response:
    def __init__(self, 
                 status_code : int | HTTPStatus = HTTPStatus.OK, 
                 protocol : str = 'HTTP/1.1', 
                 headers : dict[str, any] = None, 
                 cookies : dict[str, any] = None, 
                 body : str = ""):
        self.status_code = status_code if isinstance(status_code, HTTPStatus) else HTTPStatus(status_code)
        self.protocol = protocol
        self.headers = headers if headers is not None else {}
        self.cookies = cookies if cookies is not None else {}
        self.body = body

    @property
    def reason_phrase(self):
        return self.status_code.phrase

    def set_cookie(self, key, value):
        self.cookies[key] = value

    def add_header(self, key, value):
        self.headers[key] = value

    def to_bytes(self):
        response_line = f"{self.protocol} {self.status_code.value} {self.reason_phrase}\r\n"
        headers = "".join(f"{k}: {v}\r\n" for k, v in self.headers.items())
        cookies = "".join(f"Set-Cookie: {k}={v}\r\n" for k, v in self.cookies.items())
        return (response_line + headers + cookies + "\r\n" + self.body).encode('utf-8')

class BadRequest(Exception):
    pass

class Request:
    def __init__(self, data: bytes):
        try:
            text = data.decode("iso-8859-1")
        except UnicodeDecodeError:
            raise BadRequest("Invalid encoding")

        if "\r\n\r\n" not in text:
            raise BadRequest("Malformed HTTP request")

        head, body = text.split("\r\n\r\n", 1)
        lines = head.split("\r\n")

        method, url, protocol = lines[0].split(" ", 2)
        self.method = HTTPMethod[method.upper()]

        if protocol not in ("HTTP/1.0", "HTTP/1.1"):
            raise BadRequest("Unsupported protocol")

        self.protocol = protocol
        self.headers = {}
        self.cookies = {}

        self.slugs = {}

        for line in lines[1:]:
            if ":" not in line:
                raise BadRequest("Malformed header")
            key, value = line.split(":", 1)
            self.headers[key.strip()] = value.strip()

        if protocol == "HTTP/1.1" and "Host" not in self.headers:
            raise BadRequest("Missing Host header")

        parsed = urlparse(url)
        self.base_url = parsed.path
        self.query_params = dict(parse_qsl(parsed.query))
        self.body = body