from lapis import Lapis

test_server = Lapis()

test_server.run("localhost", 80)